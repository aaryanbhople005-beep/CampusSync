from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from config import Config
from models import db, User, Complaint, HostelRequest, LostFound, Notification
from datetime import datetime, date
import uuid

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)
    
    # Register blueprints
    from routes.auth import auth_bp
    from routes.student import student_bp
    from routes.admin import admin_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(admin_bp)
    
    @app.route('/')
    def index():
        if 'user_id' in session:
            if session['role'] == 'student':
                return redirect(url_for('student.dashboard'))
            else:
                return redirect(url_for('admin.dashboard'))
        return redirect(url_for('auth.login'))
    
    return app

if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)

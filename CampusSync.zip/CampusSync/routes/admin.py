from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import db, User, Complaint, HostelRequest, LostFound, Notification
from datetime import datetime

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash('Unauthorized Access', 'error')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

def create_notification(user_id, title, message):
    notification = Notification(user_id=user_id, title=title, message=message)
    db.session.add(notification)
    db.session.commit()

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    total_students = User.query.filter_by(role='student').count()
    total_complaints = Complaint.query.count()
    pending_complaints = Complaint.query.filter(Complaint.status.in_(['Submitted', 'Under Review', 'In Progress'])).count()
    total_hostel_requests = HostelRequest.query.count()
    pending_hostel = HostelRequest.query.filter_by(status='Pending').count()
    total_lost_found = LostFound.query.count()
    
    return render_template('admin/dashboard.html',
                         total_students=total_students,
                         total_complaints=total_complaints,
                         pending_complaints=pending_complaints,
                         total_hostel_requests=total_hostel_requests,
                         pending_hostel=pending_hostel,
                         total_lost_found=total_lost_found)

@admin_bp.route('/complaints')
@admin_required
def complaints():
    complaints = Complaint.query.order_by(Complaint.created_at.desc()).all()
    return render_template('admin/complaints.html', complaints=complaints)

@admin_bp.route('/complaints/update-status', methods=['POST'])
@admin_required
def update_complaint_status():
    complaint_id = request.form.get('complaint_id')
    new_status = request.form.get('status')
    
    valid_statuses = ['Submitted', 'Under Review', 'In Progress', 'Resolved', 'Closed']
    
    if not complaint_id or not new_status:
        flash('Complaint ID and status are required.', 'error')
        return redirect(url_for('admin.complaints'))
    
    if new_status not in valid_statuses:
        flash('Invalid status.', 'error')
        return redirect(url_for('admin.complaints'))
    
    complaint = Complaint.query.filter_by(complaint_id=complaint_id).first()
    if not complaint:
        flash('Complaint not found.', 'error')
        return redirect(url_for('admin.complaints'))
    
    old_status = complaint.status
    complaint.status = new_status
    complaint.updated_at = datetime.utcnow()
    db.session.commit()
    
    create_notification(complaint.student_id, 'Complaint Status Updated',
                      f'Your complaint {complaint.complaint_id} status changed from {old_status} to {new_status}')
    
    flash(f'Complaint {complaint_id} status updated to {new_status}.', 'success')
    return redirect(url_for('admin.complaints'))

@admin_bp.route('/hostel-requests')
@admin_required
def hostel_requests():
    requests = HostelRequest.query.order_by(HostelRequest.created_at.desc()).all()
    return render_template('admin/hostel_requests.html', requests=requests)

@admin_bp.route('/hostel-requests/update-status', methods=['POST'])
@admin_required
def update_hostel_status():
    request_id = request.form.get('request_id')
    new_status = request.form.get('status')
    
    if not request_id or not new_status:
        flash('Request ID and status are required.', 'error')
        return redirect(url_for('admin.hostel_requests'))
    
    hostel_req = HostelRequest.query.filter_by(request_id=request_id).first()
    if not hostel_req:
        flash('Hostel request not found.', 'error')
        return redirect(url_for('admin.hostel_requests'))
    
    old_status = hostel_req.status
    hostel_req.status = new_status
    hostel_req.updated_at = datetime.utcnow()
    db.session.commit()
    
    create_notification(hostel_req.student_id, 'Hostel Request Updated',
                      f'Your hostel request {hostel_req.request_id} status changed from {old_status} to {new_status}')
    
    flash(f'Hostel request {request_id} status updated to {new_status}.', 'success')
    return redirect(url_for('admin.hostel_requests'))

@admin_bp.route('/lost-found')
@admin_required
def lost_found():
    items = LostFound.query.order_by(LostFound.created_at.desc()).all()
    return render_template('admin/lost_found.html', items=items)

@admin_bp.route('/students')
@admin_required
def students():
    students = User.query.filter_by(role='student').all()
    return render_template('admin/students.html', students=students)

@admin_bp.route('/notifications', methods=['GET', 'POST'])
@admin_required
def notifications():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        message = request.form.get('message', '').strip()
        target = request.form.get('target', 'all')
        
        if not title or not message:
            flash('Title and message are required.', 'error')
            return redirect(url_for('admin.notifications'))
        
        if target == 'all':
            students = User.query.filter_by(role='student').all()
            for student in students:
                create_notification(student.id, title, message)
            flash(f'Notification sent to all {len(students)} students.', 'success')
        else:
            student_id = request.form.get('student_id')
            if student_id:
                student = User.query.get(student_id)
                if student and student.role == 'student':
                    create_notification(student.id, title, message)
                    flash(f'Notification sent to {student.full_name}.', 'success')
                else:
                    flash('Student not found.', 'error')
            else:
                flash('Please select a student or choose all students.', 'error')
        
        return redirect(url_for('admin.notifications'))
    
    students = User.query.filter_by(role='student').all()
    notifications = Notification.query.order_by(Notification.created_at.desc()).limit(50).all()
    return render_template('admin/notifications.html', students=students, notifications=notifications)

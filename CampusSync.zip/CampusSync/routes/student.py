from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import db, User, Complaint, HostelRequest, LostFound, Notification
from datetime import datetime, date
import uuid

student_bp = Blueprint('student', __name__, url_prefix='/student')

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'student':
            flash('Please log in as a student to access this page.', 'error')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

def generate_complaint_id():
    count = Complaint.query.count() + 1
    return f'CMP-{datetime.now().year}-{count:03d}'

def generate_request_id():
    count = HostelRequest.query.count() + 1
    return f'HST-{datetime.now().year}-{count:03d}'

def generate_item_id():
    count = LostFound.query.count() + 1
    return f'LF-{datetime.now().year}-{count:03d}'

def create_notification(user_id, title, message):
    notification = Notification(user_id=user_id, title=title, message=message)
    db.session.add(notification)
    db.session.commit()

@student_bp.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    complaints_count = Complaint.query.filter_by(student_id=user.id).count()
    hostel_count = HostelRequest.query.filter_by(student_id=user.id).count()
    lost_found_count = LostFound.query.filter_by(student_id=user.id).count()
    unread_notifications = Notification.query.filter_by(user_id=user.id, is_read=False).count()
    
    return render_template('student/dashboard.html', 
                         user=user,
                         complaints_count=complaints_count,
                         hostel_count=hostel_count,
                         lost_found_count=lost_found_count,
                         unread_notifications=unread_notifications)

@student_bp.route('/register-complaint', methods=['GET', 'POST'])
@login_required
def register_complaint():
    categories = ['Academic', 'Infrastructure', 'Maintenance', 'Security', 'Food', 'Transport', 'Other']
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        description = request.form.get('description', '').strip()
        
        if not title:
            flash('Complaint title is required.', 'error')
            return render_template('student/register_complaint.html', categories=categories)
        
        if not category:
            flash('Category must be selected.', 'error')
            return render_template('student/register_complaint.html', categories=categories)
        
        if not description:
            flash('Description is required.', 'error')
            return render_template('student/register_complaint.html', categories=categories)
        
        complaint = Complaint(
            complaint_id=generate_complaint_id(),
            student_id=session['user_id'],
            title=title,
            category=category,
            description=description,
            status='Submitted'
        )
        db.session.add(complaint)
        db.session.commit()
        
        create_notification(session['user_id'], 'Complaint Submitted', 
                          f'Your complaint {complaint.complaint_id} has been submitted successfully.')
        
        flash(f'Complaint submitted successfully! Your Complaint ID is: {complaint.complaint_id}', 'success')
        return redirect(url_for('student.track_complaint'))
    
    return render_template('student/register_complaint.html', categories=categories)

@student_bp.route('/track-complaint', methods=['GET', 'POST'])
@login_required
def track_complaint():
    user = User.query.get(session['user_id'])
    complaints = Complaint.query.filter_by(student_id=user.id).order_by(Complaint.created_at.desc()).all()
    
    complaint_detail = None
    if request.method == 'POST':
        complaint_id = request.form.get('complaint_id', '').strip()
        if complaint_id:
            complaint_detail = Complaint.query.filter_by(
                complaint_id=complaint_id, student_id=user.id
            ).first()
            if not complaint_detail:
                flash('Invalid Complaint ID or you do not have access to this complaint.', 'error')
    
    return render_template('student/track_complaint.html', 
                         complaints=complaints, 
                         complaint_detail=complaint_detail)

@student_bp.route('/hostel-request', methods=['GET', 'POST'])
@login_required
def hostel_request():
    hostels = ['North Campus Hostel', 'South Campus Hostel', 'East Campus Hostel', 'West Campus Hostel', 'International Hostel']
    room_types = ['Single', 'Double', 'Triple', 'Any']
    
    if request.method == 'POST':
        hostel_name = request.form.get('hostel_name', '').strip()
        room_preference = request.form.get('room_preference', '').strip()
        reason = request.form.get('reason', '').strip()
        
        if not hostel_name:
            flash('Hostel name is required.', 'error')
            return render_template('student/hostel_request.html', hostels=hostels, room_types=room_types)
        
        if not room_preference:
            flash('Room preference is required.', 'error')
            return render_template('student/hostel_request.html', hostels=hostels, room_types=room_types)
        
        if not reason:
            flash('Reason is required.', 'error')
            return render_template('student/hostel_request.html', hostels=hostels, room_types=room_types)
        
        hostel_req = HostelRequest(
            request_id=generate_request_id(),
            student_id=session['user_id'],
            hostel_name=hostel_name,
            room_preference=room_preference,
            reason=reason,
            status='Pending'
        )
        db.session.add(hostel_req)
        db.session.commit()
        
        create_notification(session['user_id'], 'Hostel Request Submitted',
                          f'Your hostel request {hostel_req.request_id} has been submitted.')
        
        flash(f'Hostel request submitted successfully! Your Request ID is: {hostel_req.request_id}', 'success')
        return redirect(url_for('student.hostel_request'))
    
    requests = HostelRequest.query.filter_by(student_id=session['user_id']).order_by(HostelRequest.created_at.desc()).all()
    return render_template('student/hostel_request.html', hostels=hostels, room_types=room_types, requests=requests)

@student_bp.route('/lost-found', methods=['GET', 'POST'])
@login_required
def lost_found():
    today = date.today().isoformat()

    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'report':
            item_name = request.form.get('item_name', '').strip()
            item_type = request.form.get('item_type', '').strip()
            description = request.form.get('description', '').strip()
            location = request.form.get('location', '').strip()
            date_str = request.form.get('date', '').strip()
            
            if not item_name:
                flash('Item name is required.', 'error')
            elif not item_type:
                flash('Item type (Lost/Found) is required.', 'error')
            elif not description:
                flash('Description is required.', 'error')
            elif not location:
                flash('Location is required.', 'error')
            elif not date_str:
                flash('Date is required.', 'error')
            else:
                try:
                    item_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                except ValueError:
                    flash('Invalid date format. Use YYYY-MM-DD.', 'error')
                    return render_template('student/lost_found.html', today=today, items=LostFound.query.filter_by(item_type='Found', status='Open').all(), user_items=LostFound.query.filter_by(student_id=session['user_id']).order_by(LostFound.created_at.desc()).all())
                
                item = LostFound(
                    item_id=generate_item_id(),
                    student_id=session['user_id'],
                    item_name=item_name,
                    item_type=item_type,
                    description=description,
                    location=location,
                    date=item_date,
                    status='Open'
                )
                db.session.add(item)
                db.session.commit()
                
                create_notification(session['user_id'], 'Lost & Found Report Submitted',
                                  f'Your {item_type.lower()} item report {item.item_id} has been submitted.')
                
                flash(f'Item reported successfully! Your Item ID is: {item.item_id}', 'success')
                return redirect(url_for('student.lost_found'))
        
        elif action == 'claim':
            item_id = request.form.get('claim_item_id', '').strip()
            if not item_id:
                flash('Item ID is required to claim.', 'error')
            else:
                item = LostFound.query.filter_by(item_id=item_id, item_type='Found', status='Open').first()
                if not item:
                    flash('Invalid Item ID or item is not available for claiming.', 'error')
                else:
                    item.status = 'Claimed'
                    item.claimed_by = session['user_id']
                    db.session.commit()
                    
                    create_notification(session['user_id'], 'Item Claimed',
                                      f'You have claimed item {item.item_id}: {item.item_name}')
                    create_notification(item.student_id, 'Item Claimed by Student',
                                      f'Your reported item {item.item_id}: {item.item_name} has been claimed.')
                    
                    flash(f'Item claimed successfully!', 'success')
                    return redirect(url_for('student.lost_found'))
    
    # Get found items available for claiming
    found_items = LostFound.query.filter_by(item_type='Found', status='Open').all()
    # Get user's own reports
    user_items = LostFound.query.filter_by(student_id=session['user_id']).order_by(LostFound.created_at.desc()).all()
    
    return render_template('student/lost_found.html', today=today, items=found_items, user_items=user_items)

@student_bp.route('/notifications')
@login_required
def notifications():
    user = User.query.get(session['user_id'])
    notifications = Notification.query.filter_by(user_id=user.id).order_by(Notification.created_at.desc()).all()
    
    # Mark as read when viewing
    for n in notifications:
        if not n.is_read:
            n.is_read = True
    db.session.commit()
    
    return render_template('student/notifications.html', notifications=notifications)

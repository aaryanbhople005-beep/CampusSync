from app import create_app
from models import db, User, Complaint, HostelRequest, LostFound, Notification
from datetime import date

app = create_app()

with app.app_context():
    db.create_all()
    
    # Create demo users
    if not User.query.filter_by(username='student').first():
        student = User(
            username='student',
            role='student',
            full_name='John Doe',
            email='student@university.edu'
        )
        student.set_password('student123')
        db.session.add(student)
    
    if not User.query.filter_by(username='admin').first():
        admin = User(
            username='admin',
            role='admin',
            full_name='Prof. Smith',
            email='admin@university.edu'
        )
        admin.set_password('admin123')
        db.session.add(admin)
    
    db.session.commit()
    
    # Add sample data for testing
    student_user = User.query.filter_by(username='student').first()
    admin_user = User.query.filter_by(username='admin').first()
    
    if student_user and not Complaint.query.first():
        # Sample complaints
        complaints = [
            Complaint(
                complaint_id='CMP-2024-001',
                student_id=student_user.id,
                title='WiFi Not Working in Library',
                category='Infrastructure',
                description='The WiFi in the main library has been down for 3 days.',
                status='Under Review'
            ),
            Complaint(
                complaint_id='CMP-2024-002',
                student_id=student_user.id,
                title='Broken Chair in Classroom 101',
                category='Maintenance',
                description='Chair number 5 in classroom 101 is broken.',
                status='Resolved'
            )
        ]
        for c in complaints:
            db.session.add(c)
    
    if student_user and not HostelRequest.query.first():
        # Sample hostel requests
        requests = [
            HostelRequest(
                request_id='HST-2024-001',
                student_id=student_user.id,
                hostel_name='North Campus Hostel',
                room_preference='Single',
                reason='Need quiet environment for studies',
                status='Approved'
            ),
            HostelRequest(
                request_id='HST-2024-002',
                student_id=student_user.id,
                hostel_name='South Campus Hostel',
                room_preference='Double',
                reason='Want to share with friend',
                status='Pending'
            )
        ]
        for r in requests:
            db.session.add(r)
    
    if student_user and not LostFound.query.first():
        # Sample lost & found items
        items = [
            LostFound(
                item_id='LF-2024-001',
                student_id=student_user.id,
                item_name='Black Backpack',
                item_type='Lost',
                description='Black Nike backpack with laptop inside',
                location='Main Library',
                date=date(2024, 1, 15),
                status='Open'
            ),
            LostFound(
                item_id='LF-2024-002',
                student_id=student_user.id,
                item_name='iPhone 13',
                item_type='Found',
                description='White iPhone 13 found near cafeteria',
                location='Cafeteria',
                date=date(2024, 1, 20),
                status='Claimed'
            )
        ]
        for i in items:
            db.session.add(i)
    
    if student_user and not Notification.query.first():
        # Sample notifications
        notifications = [
            Notification(
                user_id=student_user.id,
                title='Complaint Status Updated',
                message='Your complaint CMP-2024-001 is now Under Review'
            ),
            Notification(
                user_id=student_user.id,
                title='Hostel Request Approved',
                message='Your hostel request HST-2024-001 has been approved'
            ),
            Notification(
                user_id=admin_user.id if admin_user else student_user.id,
                title='New Complaint Submitted',
                message='New complaint CMP-2024-002 submitted by John Doe'
            )
        ]
        for n in notifications:
            db.session.add(n)
    
    db.session.commit()
    print('Database initialized with demo data!')
